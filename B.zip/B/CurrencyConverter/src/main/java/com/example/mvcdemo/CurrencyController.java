package com.example.mvcdemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class CurrencyController {
	
	
	@Autowired
	ConverterExp service;
	
	@RequestMapping(value="/home",method=RequestMethod.GET)
	public String showLoginPage(ModelMap model) {
		return "home";
	}
	
	@RequestMapping(value="/home",method=RequestMethod.POST)
	public String showWelcomePage(ModelMap model, @RequestParam String from,@RequestParam String to,@RequestParam String inp)
	{
			model.addAttribute("from",from);
	    	model.addAttribute("to", to);
	    	model.addAttribute("inp", inp);
	    	return "result";
	    }
		
	@GetMapping(path="/currencymsg")
	public String welcome(@RequestParam String from,@RequestParam String to,@RequestParam String inp,Model model) {
		//System.out.println(from);
		//System.out.println(inp);
		Double result=service.getCurrencyMsg(from, to, inp);
		model.addAttribute("result",result);
		//System.out.println(result);
		return "result";
}
}
