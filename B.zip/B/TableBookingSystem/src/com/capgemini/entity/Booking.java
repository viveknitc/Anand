package com.capgemini.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Booking {
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
private int bookingid;
private String name;
private String mobile;
private String email;
private String date;
private String time;
public Booking() {
	super();
}
public Booking(int bookingid, String name, String mobile, String email,
		String date, String time) {
	super();
	this.bookingid = bookingid;
	this.name = name;
	this.mobile = mobile;
	this.email = email;
	this.date = date;
	this.time = time;
}
public int getBookingid() {
	return bookingid;
}
public void setBookingid(int bookingid) {
	this.bookingid = bookingid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobile() {
	return mobile;
}
public void setMobile(String mobile) {
	this.mobile = mobile;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
@Override
public String toString() {
	return "Booking [bookingid=" + bookingid + ", name=" + name + ", mobile="
			+ mobile + ", email=" + email + ", date=" + date + ", time=" + time
			+ "]";
}





}
