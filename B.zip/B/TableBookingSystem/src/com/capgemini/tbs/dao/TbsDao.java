package com.capgemini.tbs.dao;

import com.capgemini.entity.Booking;
import com.capgemini.entity.Registration;

public interface TbsDao {

	public int userRegistration(Registration registration);
	public int booking(Booking booking);
	public boolean validateUser(Registration registration);
}
