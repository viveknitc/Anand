package com.capgemini.tbs.daoimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.capgemini.entity.Booking;
import com.capgemini.entity.Registration;
import com.capgemini.tbs.dao.TbsDao;

public class DaoImpl implements TbsDao {

	@Autowired
	JdbcTemplate jdbctemplate; 
	@Override
	public int userRegistration(Registration registration) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int booking(Booking booking) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean validateUser(Registration registration) {
		boolean userPresent=false;
		String selectQuery="select count(*) from checkUser where username=? and password=?";
		int count=(int)jdbctemplate.queryForInt(selectQuery,registration.getUsername(),registration.getPassword());
		if(count==1)
		{
			userPresent=true;
		}
		return userPresent;
	}

}
