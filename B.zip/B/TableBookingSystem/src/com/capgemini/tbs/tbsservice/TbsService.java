package com.capgemini.tbs.tbsservice;

import com.capgemini.entity.Booking;
import com.capgemini.entity.Registration;

public interface  TbsService {

	public int userRegistration(Registration registration);
	public int booking(Booking booking);
}
