package com.capgemini.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.capgemini.HelloWorld;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.capgemini")
public class Client {

	public static void main(String[] args) {
		
		ApplicationContext appcontext=SpringApplication.run(Client.class, args);
		//HelloWorld helloworld=(HelloWorld)appcontext.getBean("HelloWorld.class");
		HelloWorld hw=(HelloWorld)appcontext.getBean(HelloWorld.class);
		String message=hw.sayHello();
		System.out.println(message);

	}

}
