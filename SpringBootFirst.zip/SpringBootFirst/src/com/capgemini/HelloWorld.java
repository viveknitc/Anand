package com.capgemini;

import org.springframework.stereotype.Component;

@Component
public class HelloWorld {

	public String sayHello()
	{
		return"hello, how r you";
	}
}
