package com.cg.dao;
import javax.sql.DataSource;

import com.cg.bean.Booking;
import com.cg.bean.Registration;
import com.cg.bean.UserBean;
 
public interface ICombatDAO {
	public abstract void setDataSource(DataSource dataSource);
	public abstract boolean authenticateUser(Registration registration);
	public int userRegistration(Registration registration);
	public int booking(Booking booking);
}