package com.cg.service;

import com.cg.bean.Booking;
import com.cg.bean.Registration;
import com.cg.bean.UserBean;

public interface ICombatService {
	public abstract boolean authenticateUser(Registration registration);
	public int userRegistration(Registration registration);
	public int booking(Booking booking);
}

