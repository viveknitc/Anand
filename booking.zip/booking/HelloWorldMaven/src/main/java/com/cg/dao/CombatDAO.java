package com.cg.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.cg.bean.Booking;
import com.cg.bean.Registration;

public class CombatDAO implements ICombatDAO {
	
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
 
	@SuppressWarnings("deprecation")
	public boolean authenticateUser(Registration registration){
		boolean userExists = false;
		int rowcount = jdbcTemplate.queryForInt("select count(*) from tbsreg " +
				" where uname = ? and password = ?",
				registration.getUsername(),registration.getPassword());
		if(rowcount==1){
			userExists = true;
		}
		return userExists;
	}

	public int userRegistration(Registration registration) {
		System.out.println(registration);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String insertQuery = "insert into tbsreg values(?, ?, ?, ?)";
		Object[] params = new Object[]{registration.getUsername(),registration.getPassword(),registration.getEmail(),registration.getMobile()};
		int count = jdbcTemplate.update(insertQuery, params);
		
		if(count > 0){
			String lastQuery = "select max(userid) from tbsreg";
			count = jdbcTemplate.queryForInt(lastQuery);
			System.out.println(count);
			
		}	
		
		return count;		  
	}

	
	public int booking(Booking booking) {
		System.out.println(booking);
		KeyHolder keyHolder = new GeneratedKeyHolder();
		String insertQuery = "insert into booking values(?, ?, ?, ?, ?)";
		Object[] params = new Object[]{booking.getName(),booking.getMobile(),booking.getEmail(),booking.getDate(),booking.getTime()};
		int count = jdbcTemplate.update(insertQuery, params);
		
		if(count > 0){
			String lastQuery = "select max(bookingid) from booking";
			count = jdbcTemplate.queryForInt(lastQuery);
			System.out.println(count);
			
		}	
		
		return count;		  

	}
}
