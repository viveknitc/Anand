package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.bean.Booking;
import com.cg.bean.Registration;
import com.cg.bean.UserBean;
import com.cg.dao.ICombatDAO;
 
public class CombatService implements ICombatService {
 
	@Autowired
	private ICombatDAO combatDAO;
 
	public boolean authenticateUser(Registration registration){
		return combatDAO.authenticateUser(registration);
	}

	public int userRegistration(Registration registration) {
		
		return combatDAO.userRegistration(registration);
	}

	public int booking(Booking booking) {
		return combatDAO.booking(booking);
	}

	

}