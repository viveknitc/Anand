package com.cg.model;

public class LoginBean {

	private int empid;
	private String ename;
	private String username;
	private String password;
	private String managerid;
	private String role;
	public LoginBean() {
		// TODO Auto-generated constructor stub
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getManagerid() {
		return managerid;
	}
	public void setManagerid(String managerid) {
		this.managerid = managerid;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "LoginBean [empid=" + empid + ", ename=" + ename + ", username="
				+ username + ", password=" + password + ", managerid="
				+ managerid + ", role=" + role + "]";
	}
	
	
	
	
}
