package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.catalina.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.ChangePassword;
import com.cg.model.Contact;
import com.cg.model.LoginBean;
import com.cg.model.Status;
import com.cg.service.EmpService;


@Controller
public class ManagerEmployeeCntlr {
	@Autowired
	EmpService empservice;
	Status status;
	
	@RequestMapping("toLogin")
	public String toLogin(Model model) {
		// Make sure to add model of UserBean in which login 
		// userName and password will be stored from the login form 
		model.addAttribute("loginBean", new LoginBean());
		// "login" will be resolved to login.jsp
		// where login-form is presented to user
		return "login";
	}
	
	@RequestMapping("manager")
	public String tomanager(Model model) {
		// Make sure to add model of UserBean in which login 
		// userName and password will be stored from the login form 
		model.addAttribute("loginBean", new LoginBean());
		// "login" will be resolved to login.jsp
		// where login-form is presented to user
		return "manager";
	}
	
	@RequestMapping("doLogin")
	public ModelAndView doLogin(@ModelAttribute @Valid LoginBean loginBean,BindingResult result,HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		ModelAndView view = new ModelAndView("login");
		// If input bean does not have any validation error then proceed
		if(!result.hasFieldErrors()) {
			// If not a valid user then add error
			// else proceed to user welcome page
			if(!empservice.authenticateUser(loginBean)) {
				result.addError(new ObjectError("error", "Invalid Credentials"));
				view.addObject("message", "Username or Password is wrong!!");
			} else {
				//session.setAttribute("lbean",loginBean);
				String name=request.getParameter("username");
				String role=request.getParameter("role");
				session.setAttribute("user",name);
				//session.setAttribute("rol",role);
				System.out.println(name);
				if(role.equalsIgnoreCase("manager"))
				{
				view.setViewName("manager");//employee
				}
				else if(role.equalsIgnoreCase("employee"))
				{
					view.setViewName("employee");
				}
			}
		}
		return view;
	}
	
	@RequestMapping("verifyuser")
	public ModelAndView verifyUser(@ModelAttribute @Valid LoginBean loginBean,BindingResult result,HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		ModelAndView view = new ModelAndView("usercheck");
		// If input bean does not have any validation error then proceed
		if(!result.hasFieldErrors()) {
			// If not a valid user then add error
			// else proceed to user welcome page
			if(!empservice.verifyUser(loginBean)) {
				result.addError(new ObjectError("err", "Invalid username"));
			} else {
				view.setViewName("changepassword");//employee
			}
		}
		return view;
	}
	 @RequestMapping(value="/logout",method = RequestMethod.GET)
     public String logout(HttpServletRequest request){
         HttpSession httpSession = request.getSession();
         httpSession.invalidate();
         return "login";
     }
	    @RequestMapping(value = "/newEmployee", method = RequestMethod.GET)
	    public ModelAndView newContact(ModelAndView model) {
	        LoginBean loginBean = new LoginBean();
	        model.addObject("loginBean", loginBean);
	        model.setViewName("addEmployee");
	        return model;
	    }
	    
	    @RequestMapping(value = "/addstatus", method = RequestMethod.GET)
	    public ModelAndView newStatus(ModelAndView model) {
	        Status status = new Status();
	        model.addObject("status", status);
	        model.setViewName("addStatus");
	        return model;
	    }
	    
	    @RequestMapping(value = "/contact", method = RequestMethod.GET)
	    public ModelAndView newContact1(ModelAndView model,Contact contact) {
	       empservice.addContact(contact);
	        model.setViewName("contact");
	        return model;
	    }
	    
	    @RequestMapping(value = "/fillstatus", method = RequestMethod.GET)
	    public ModelAndView newFeedStatus(ModelAndView model, Status status) {
	    	empservice.addStatus(status);
	        model.setViewName("employee");
	        return model;
	    }
	    @RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	    public ModelAndView saveEmployee(@ModelAttribute LoginBean loginBean) {
	        if (loginBean.getEmpid() == 0) { // if employee id is 0 then creating the
	            // employee other updating the employee
	            empservice.addEmployee(loginBean);
	        } else {
	            empservice.updateEmployee(loginBean);
	        }
	        return new ModelAndView("manager");
	    }
	    
		@RequestMapping(value = "/listdeatils")
	    public ModelAndView listEmployee(@ModelAttribute("loginBean") ModelAndView model,HttpSession session,HttpServletRequest request, HttpServletResponse response) throws IOException {
			String username=(String)session.getAttribute("user");
	    	List<LoginBean> listEmployee = empservice.listEmployee(username);
	    	System.out.println(listEmployee.size());
	        model.addObject("listEmployee", listEmployee);
	        model.setViewName("listmng");
	        return model;
	    }
	    @RequestMapping(value = "/liststatusm")
	    public ModelAndView listStatusm(ModelAndView model,HttpSession session) throws IOException {
	    	String username=(String)session.getAttribute("user");
	    	//String role=(String)session.getAttribute("rol");
	        //List<Status> listStatuse = empservice.listStatus(username);
	        List<Status> listStatusm = empservice.listStatusm(username);
	        model.addObject("listStatusm", listStatusm);
	        model.setViewName("liststatusm");
	        return model;
	    }
	    
	   @RequestMapping(value = "/liststatuse")
	    public ModelAndView listStatuse(ModelAndView model,HttpSession session) throws IOException {
	    	String username=(String)session.getAttribute("user");
	        List<Status> listStatuse = empservice.listStatus(username);
	        model.addObject("listStatuse", listStatuse);
	        model.setViewName("liststatuse");
	        return model;
	    }
	    
	    @RequestMapping(value="/editemp/{empid}")  
	    public ModelAndView edit(@PathVariable int empid){
	        LoginBean loginBean=empservice.getEmployeeById(empid) ; 
	        return new ModelAndView("edit","command",loginBean);  
	    } 
	    
	    @RequestMapping(value="/editstatusm/{statusid}")  
	    public ModelAndView editsm(@PathVariable int statusid){
	        Status status=empservice.getStatusById(statusid) ; 
	        return new ModelAndView("editsm","command",status);  
	    } 
	    
	    @RequestMapping(value="/editstatuse/{statusid}")  
	    public ModelAndView editse(@PathVariable int statusid){
	        Status status=empservice.getStatusById(statusid) ; 
	        return new ModelAndView("editse","command",status);  
	    } 
	    //for employee
	    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
	    public ModelAndView editssave(@ModelAttribute("loginBean") LoginBean loginBean){  
	        empservice.updateEmployee(loginBean); 
	        return new ModelAndView("manager");  
	    } 
	    //forstatus
	    @RequestMapping(value="/editssavem",method = RequestMethod.POST)  
	    public ModelAndView editsavem(@ModelAttribute("status") Status status){  
	        empservice.updateStatus(status); 
	        return new ModelAndView("manager");  
	    }  
	    
	    @RequestMapping(value="/editssavee",method = RequestMethod.POST)  
	    public ModelAndView editsavee(@ModelAttribute("status") Status status){  
	        empservice.updateStatus(status); 
	        return new ModelAndView("employee");  
	    }  
	    @RequestMapping(value="/deleteemp/{empid}",method = RequestMethod.GET)  
	    public ModelAndView delete(@PathVariable int empid){  
	        empservice.deleteEmployee(empid);  
	        return new ModelAndView("redirect:/manager");  
	    }  
	    
	    @RequestMapping(value="/updatepassword",method = RequestMethod.POST)  
	    public ModelAndView updatepass(@ModelAttribute("change") ChangePassword change,HttpServletRequest request, HttpServletResponse response){ 
	    	String pass1=request.getParameter("newPassword");
	    	String pass2=request.getParameter("confirmPassword");
	    	if(pass1.equalsIgnoreCase(pass2))
	    	{
	        empservice.updatePassword(change);
	    	}
	    	else
	    	{
	    		System.out.println("Invalid OldPassword");
	    	}
	    	return new ModelAndView("login"); 
	    }
	   @RequestMapping(value = "/generate/excel.htm", method = RequestMethod.GET)
	    ModelAndView generateExcel(HttpServletRequest request,
	      HttpServletResponse response,HttpSession session) throws Exception {
	     System.out.println("Calling generateExcel()...");
	     String username=(String)session.getAttribute("user");
	     List<Status> st=empservice.listStatusm(username);
	     System.out.println(st.size());
	     System.out.println(st);
	     ModelAndView modelAndView = new ModelAndView("excelView", "status", st);
	     System.out.println("Calling generateExcel()...");
	     return modelAndView;
}
}