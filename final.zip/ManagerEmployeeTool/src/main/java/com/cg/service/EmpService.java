package com.cg.service;

import java.util.List;

import com.cg.model.ChangePassword;
import com.cg.model.Contact;
import com.cg.model.LoginBean;
import com.cg.model.Status;

public interface EmpService {

	public List<LoginBean> listEmployee(String username);
	public List<Status> listStatus(String username);
	public List<Status> listStatusm(String username);
	public int addEmployee(LoginBean loginBean);
	public void updateEmployee(LoginBean loginBean);
	public void updateStatus(Status status);
	public void deleteEmployee(int empid);
	public LoginBean getEmployeeById(int empid);
	public Status getStatusById(int statusid);
	public boolean authenticateUser(LoginBean loginBean);
	public void addStatus(Status status);
	public boolean verifyUser(LoginBean loginBean);
	public void updatePassword(ChangePassword change);
	boolean employeeExists(int empid);
	public int addContact(Contact contact);
}
