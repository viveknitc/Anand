package com.cg.excelview;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import com.cg.model.Status;

@Component
public class ExcelView extends AbstractExcelView {
	 @Override
	 protected void buildExcelDocument(Map model, HSSFWorkbook workbook,
	   HttpServletRequest request, HttpServletResponse response)
	   throws Exception {

		  @SuppressWarnings("unchecked")
		List<Status> stat = (List<Status>) model.get("status");
		  HSSFSheet sheet = workbook.createSheet("excelView");

	  HSSFRow header = sheet.createRow(0);
	  header.createCell(0).setCellValue("statusid");
	  header.createCell(1).setCellValue("empuserid");
	  header.createCell(2).setCellValue("managerid");
	  header.createCell(3).setCellValue("status");
	  header.createCell(4).setCellValue("date");
	  header.createCell(5).setCellValue("time");
	  
	  int counter = 1;
	 for (Status st : stat) {
		   HSSFRow row = sheet.createRow(counter++);
		   row.createCell(0).setCellValue(st.getStatusid());
		   row.createCell(1).setCellValue(st.getEmpuserid());
		   row.createCell(2).setCellValue(st.getManagerid());
		   row.createCell(3).setCellValue(st.getStatus());
		   row.createCell(4).setCellValue(st.getDate().toString());
		   row.createCell(5).setCellValue(st.getTime().toString());
		  }
	 }
	}
