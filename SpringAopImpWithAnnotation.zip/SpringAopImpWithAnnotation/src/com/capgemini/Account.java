package com.capgemini;

public class Account {

	
	public void deposit(int amount)
	{
		System.out.println("Amont deposited");
	}
	
	public void withdraw()
	{
		System.out.println("Amount withdraw");
	}
}
