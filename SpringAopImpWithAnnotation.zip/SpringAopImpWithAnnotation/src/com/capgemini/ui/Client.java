package com.capgemini.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.Account;

public class Client {

	public static void main(String[] args) {


		ApplicationContext appcontext=new ClassPathXmlApplicationContext("applicationConfigData.xml");
		Account account=(Account)appcontext.getBean("target");
		account.deposit(4563);
		account.withdraw();
	}

}
