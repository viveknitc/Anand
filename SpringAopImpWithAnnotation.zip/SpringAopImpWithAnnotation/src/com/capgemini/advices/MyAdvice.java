package com.capgemini.advices;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

public class MyAdvice {

	
	@Pointcut("execution(* com.capgemini.*.d*(..))")
	public void apply()
	{
		
	}
	@Before("apply()")
	public void validate()
	{
		System.out.println("security code");
	}
	
	public void doLoging(JoinPoint jp)
	{
		Signature sign=jp.getSignature();
		String name=sign.getName();
		System.out.println("Logging code will go here"+name);
		System.out.println("value of amount is"+jp.getArgs()[0]);
	}
	
	public void manageTransaction(ProceedingJoinPoint pjp) throws Throwable
	{
		System.out.println("Transaction mangement code wil go here");
		pjp.proceed();
		System.out.println("Transaction commited and end here");
	}
}
