package com.capgemini.ui;

import java.util.ArrayList;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemin.spel.User;
import com.capgemini.City;
import com.capgemini.CityList;
import com.capgemini.Employee;

public class Client {

	public static void main(String[] args) {
	
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		/*Employee employee=(Employee)applicationContext.getBean("emp");
		System.out.println(employee);
		CityList cityList=(CityList)applicationContext.getBean("cl");
		ArrayList<City> allcity=cityList.getCityList();
		for(City city:allcity)
		{
			System.out.println("CityList"+ city);
		}*/
		User user=(User)applicationContext.getBean("user1");
		System.out.println(user);
	}

}
