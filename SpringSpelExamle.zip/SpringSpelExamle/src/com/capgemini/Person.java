package com.capgemini;

public class Person {

	private int pid;
	private String pName;
	private int page;
	public Person() {
		super();
	}
	public Person(int pid, String pName, int page) {
		super();
		this.pid = pid;
		this.pName = pName;
		this.page = page;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	@Override
	public String toString() {
		return "Person [pid=" + pid + ", pName=" + pName + ", page=" + page
				+ "]";
	}
	
	
	
}
