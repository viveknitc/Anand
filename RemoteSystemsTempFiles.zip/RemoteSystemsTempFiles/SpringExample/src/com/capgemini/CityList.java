package com.capgemini;

import java.util.ArrayList;

public class CityList {

	ArrayList<City> cityList;

	public ArrayList<City> getCityList() {
		return cityList;
	}

	public void setCityList(ArrayList<City> cityList) {
		this.cityList = cityList;
	}
	
	
}
