package com.capgemini;

public class City {

	private String cityName;
	private String cityState;
	private int cityPopulation;
	public City() {
		super();
	}
	public City(String cityName, String cityState, int cityPopulation) {
		super();
		this.cityName = cityName;
		this.cityState = cityState;
		this.cityPopulation = cityPopulation;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCityState() {
		return cityState;
	}
	public void setCityState(String cityState) {
		this.cityState = cityState;
	}
	public int getCityPopulation() {
		return cityPopulation;
	}
	public void setCityPopulation(int cityPopulation) {
		this.cityPopulation = cityPopulation;
	}
	@Override
	public String toString() {
		return "City [cityName=" + cityName + ", cityState=" + cityState
				+ ", cityPopulation=" + cityPopulation + "]";
	}
	
	
}
	
	