package com.proliferay.model;

import org.hibernate.validator.constraints.NotEmpty;

public class Customer {
	
	@NotEmpty(message = "Please enter your first Name")
	private String firstName;
	@NotEmpty(message = "Please enter your last Name")
	private String lastName;
	private String address;
	private String contact;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

}
