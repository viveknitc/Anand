package com.proliferay.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.proliferay.model.Customer; 

@Controller

public class FormController {

	@RequestMapping("/")
	public ModelAndView showHomePage() {
		return new ModelAndView("home", "customer", new Customer());
	}

	@RequestMapping(value = "/addCustomer", method = RequestMethod.POST)
	public String addCustomer(@ModelAttribute("customer") @Valid Customer customer, BindingResult result) {
		
		if (result.hasErrors()) {

			return "home";

		} else {
			
			return "result";
		}

	}
}
