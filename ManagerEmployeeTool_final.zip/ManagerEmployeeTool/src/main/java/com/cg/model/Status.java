package com.cg.model;

public class Status {
	
	private int statusid;
	private String empuserid;
	private String managerid;
	private String status;
	private String date;
	private String time;
	
	public Status() {
		// TODO Auto-generated constructor stub
	}

	public int getStatusid() {
		return statusid;
	}

	public void setStatusid(int statusid) {
		this.statusid = statusid;
	}

	public String getEmpuserid() {
		return empuserid;
	}

	public void setEmpuserid(String empuserid) {
		this.empuserid = empuserid;
	}

	public String getManagerid() {
		return managerid;
	}

	public void setManagerid(String managerid) {
		this.managerid = managerid;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Status [statusid=" + statusid + ", empuserid=" + empuserid
				+ ", managerid=" + managerid + ", status=" + status + ", date="
				+ date + ", time=" + time + "]";
	}

	
	
	

}
