package com.cg.dao;

import java.util.List;

import com.cg.model.ChangePassword;
import com.cg.model.LoginBean;
import com.cg.model.Status;

public interface EmpDao {

	public List<LoginBean> listEmployee(String username);
	public List<Status> listStatus(String username);
	public List<Status> listStatusm(String username);
	public int addEmployee(LoginBean loginBean);
	public void addStatus(Status status);
	public void updateEmployee(LoginBean loginBean);
	public void updateStatus(Status status);
	public void updatePassword(ChangePassword change);
	public void deleteEmployee(int empid);
	//public void deleteStatus(int statusid);
	public LoginBean getEmployeeById(int empid);
	public Status getStatusById(int statusid);
	boolean employeeExists(int empid, String ename);
	public boolean authenticateUser(LoginBean loginBean);
	public boolean verifyUser(LoginBean loginBean);
	
	//public HashMap<String,String> changePassword(ChangePassword change);
}
