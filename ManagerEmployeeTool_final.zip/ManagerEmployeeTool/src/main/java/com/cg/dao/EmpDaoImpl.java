package com.cg.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper; 
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.ChangePassword;
import com.cg.model.LoginBean;
import com.cg.model.Status;
@Repository
@Transactional
public class EmpDaoImpl implements EmpDao {
	@Autowired
	public JdbcTemplate jdbcTemplate;

	
	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	public List<LoginBean> listEmployee(String username) {
		String sql="select * from details where managerid='"+username+"'";
		List<LoginBean> listContact= jdbcTemplate.query(sql, new RowMapper<LoginBean>(){

			public LoginBean mapRow(ResultSet rs, int arg1)
					throws SQLException {
				LoginBean loginBean=new LoginBean();
				loginBean.setEmpid(rs.getInt(1));
				loginBean.setEname(rs.getString(2));
				loginBean.setUsername(rs.getString(3));
				loginBean.setPassword(rs.getString(4));
				loginBean.setManagerid(rs.getString(5));
				loginBean.setRole(rs.getString(6));
				return loginBean;
			}
		});
		return listContact;
		}
	
	public List<Status> listStatus(String username) {
		String sql="select * from status where empuserid='"+username+"'"; 
		List<Status> listStatus= jdbcTemplate.query(sql, new RowMapper<Status>(){

			public Status mapRow(ResultSet rs, int arg1)
					throws SQLException {
				Status status=new Status();
				status.setStatusid(rs.getInt(1));
				status.setEmpuserid(rs.getString(2));
				status.setManagerid(rs.getString(3));
				status.setStatus(rs.getString(4));
				status.setDate(rs.getString(5));
				status.setTime(rs.getString(6));
				return status;
			}
		});
		return listStatus;
		}
	public List<Status> listStatusm(String username) {
		String sql="select * from status where managerid='"+username+"'"; 
		List<Status> listStatus= jdbcTemplate.query(sql, new RowMapper<Status>(){

			public Status mapRow(ResultSet rs, int arg1)
					throws SQLException {
				Status status=new Status();
				status.setStatusid(rs.getInt(1));
				status.setEmpuserid(rs.getString(2));
				status.setManagerid(rs.getString(3));
				status.setStatus(rs.getString(4));
				status.setDate(rs.getString(5));
				status.setTime(rs.getString(6));
				return status;
			}
		});
		return listStatus;
		}
	public int addEmployee(LoginBean loginBean) {
		String sql="insert into details(empid,ename,username,password,managerid,role) values("+loginBean.getEmpid()+",'"+loginBean.getEname()+"','"+loginBean.getUsername()+"','"+loginBean.getPassword()+"','"+loginBean.getManagerid()+"','"+loginBean.getRole()+"')";
		return jdbcTemplate.update(sql);
	}

	public void updateEmployee(LoginBean loginBean) {
		
		String sql="update details set Ename='"+loginBean.getEname()+"',username='"+loginBean.getUsername()+"',password='"+loginBean.getPassword()+"',managerid='"+loginBean.getManagerid()+"',role='"+loginBean.getManagerid()+"' where empid="+loginBean.getEmpid()+"";
		jdbcTemplate.update(sql);
	}

	public void deleteEmployee(int empid) {
		String sql="delete from details where empid="+empid+"";
		jdbcTemplate.update(sql);
	}

	public LoginBean getEmployeeById(int empid) {
		String sql="select * from details where empid=?";
		return jdbcTemplate.queryForObject(sql,new Object[]{empid},new BeanPropertyRowMapper<LoginBean>(LoginBean.class));
	}

	public boolean employeeExists(int empid, String ename) {
		String sql = "SELECT count(*) FROM details WHERE empid = ? and ename=?";
		int count = jdbcTemplate.queryForObject(sql, Integer.class, empid, ename);
		if(count == 0) {
    		        return false;
		} else {
			return true;
		}
	}

	@SuppressWarnings("deprecation")
	public boolean authenticateUser(LoginBean loginBean){
		boolean userExists = false;
		int rowcount = jdbcTemplate.queryForInt("select count(*) from details " +
				" where username = ? and password = ?" ,
				loginBean.getUsername(),loginBean.getPassword());
		if(rowcount==1){
			userExists = true;
		}
		return userExists;
	}
	public void addStatus(Status status) {
		final long CURRENT_TIME_MILLIS = System.currentTimeMillis();
		/*DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd");
		LocalDate localDate = LocalDate.now();*/
		long millis=System.currentTimeMillis();  
		java.sql.Date date=new java.sql.Date(millis); 
		String dat=date.toString();
		Date instant = new Date(CURRENT_TIME_MILLIS);
	    SimpleDateFormat sdf = new SimpleDateFormat( "HH:mm:ss" );
	     String time = sdf.format( instant );
		String sql="insert into status(empuserid,managerid,status,sdate,stime) values('"+status.getEmpuserid()+"','"+status.getManagerid()+"','"+status.getStatus()+"','"+dat+"','"+time+"')";
		jdbcTemplate.update(sql);
		
	}
	public void updateStatus(Status status) {
		String sql="update status set status='"+status.getStatus()+"'where statusid="+status.getStatusid()+"";
		jdbcTemplate.update(sql);
		
	}
	public Status getStatusById(int statusid) {
		String sql="select * from status where statusid=?";
		return jdbcTemplate.queryForObject(sql,new Object[]{statusid},new BeanPropertyRowMapper<Status>(Status.class));
		
	}
	@SuppressWarnings("deprecation")
	public boolean verifyUser(LoginBean loginBean) {
		boolean usernameExists = false;
		int rowcount = jdbcTemplate.queryForInt("select count(*) from details " +
				" where username = ?" ,loginBean.getUsername());
		if(rowcount==1){
			usernameExists = true;
		}
		return usernameExists;
	}
	public void updatePassword(ChangePassword change) {
		String sql="update details set password='"+change.getNewPassword()+"' where password='"+change.getOldPassword()+"'";
		jdbcTemplate.update(sql);
		
		
	}
	
}
