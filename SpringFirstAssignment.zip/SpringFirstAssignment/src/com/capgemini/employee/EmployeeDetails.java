package com.capgemini.employee;

public class EmployeeDetails {

	private int employeeId;
	private String employeeName;
	private int empSal;
	private String bu;
	private int age;
	public EmployeeDetails() {
		super();
	}
	public EmployeeDetails(int employeeId, String employeeName, int empSal,
			String bu, int age) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.empSal = empSal;
		this.bu = bu;
		this.age = age;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	public String getBu() {
		return bu;
	}
	public void setBu(String bu) {
		this.bu = bu;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "EmployeeDetails [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", empSal=" + empSal + ", bu=" + bu + ", age="
				+ age + "]";
	}
	
	
	
}
