package com.capgemini.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.employee.EmployeeDetails;

public class Client {

	public static void main(String[] args) {
		
		ApplicationContext applicationcontext=new ClassPathXmlApplicationContext("applicationConfigData.xml");
		EmployeeDetails empd=(EmployeeDetails)applicationcontext.getBean("emp");
		System.out.println(empd);
		

	}

}
