package com.fundsbank.service;

import com.fundsbank.model.ComplaintModel;

public interface RaisedComplaintService {

	public int insertComplaint(ComplaintModel complaint);
	public ComplaintModel getComplaint(int complaintId);
}
