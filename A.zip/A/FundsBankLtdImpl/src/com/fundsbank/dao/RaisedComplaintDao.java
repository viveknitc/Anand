package com.fundsbank.dao;

import com.fundsbank.model.ComplaintModel;

public interface RaisedComplaintDao {

	public int insertComplaint(ComplaintModel complaint);
	public ComplaintModel getComplaint(int complaintId);
}
