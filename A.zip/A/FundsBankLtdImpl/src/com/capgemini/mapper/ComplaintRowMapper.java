package com.capgemini.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.fundsbank.model.ComplaintModel;

public class ComplaintRowMapper implements RowMapper<ComplaintModel> {
	@Override
	public ComplaintModel mapRow(ResultSet rs, int count) throws SQLException {
		System.out.println("mapper "+rs.getInt(1));
		ComplaintModel complaintModel = new ComplaintModel(rs.getInt(1),rs.getInt(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
		//ComplaintModel complaintModel = new ComplaintModel(rs.getInt(1));
		return complaintModel;
	}	
}
