package com.cg.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.bean.Employee;
@Repository
public class EmpDaoImpl implements EmpDao {
	@Autowired
	private SessionFactory sessionFactory;
	
	public EmpDaoImpl() {
		// TODO Auto-generated constructor stub
	}
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void addEmployee(Employee employee) {
		sessionFactory.getCurrentSession().saveOrUpdate(employee);
	}

	public void updateEmployee(Employee employee) {
		sessionFactory.getCurrentSession().update(employee);
	}

	public Employee getEmployeeById(int empid) {
		return (Employee) sessionFactory.getCurrentSession().get(Employee.class, empid);
	}

	@SuppressWarnings("unchecked")
	public List<Employee> listEmployee() {
		return sessionFactory.getCurrentSession().createQuery("from details").list();
	}

	public void deleteEmployee(int empid) {
		Employee employee=(Employee)sessionFactory.getCurrentSession().load(Employee.class, empid);
		if(employee!=null)
			this.sessionFactory.getCurrentSession().delete(employee);
	}

}
