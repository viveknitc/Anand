package com.cg.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="details")
public class Employee implements Serializable {

	private static final long serialVersionUID = -3465813074586302847L;
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO)
	private int empid;
	@Column
	private String ename;
	@Column
	private String role;
	@Column
	private String status;
	@Column
	private String city;
	@Column
	private String mobile;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empid, String ename, String role, String status,
			String city, String mobile) {
		super();
		this.empid = empid;
		this.ename = ename;
		this.role = role;
		this.status = status;
		this.city = city;
		this.mobile = mobile;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", ename=" + ename + ", role="
				+ role + ", status=" + status + ", city=" + city + ", mobile="
				+ mobile + "]";
	}
	
	
}
