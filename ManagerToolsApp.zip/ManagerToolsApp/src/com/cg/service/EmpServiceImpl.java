package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.EmpDao;

@Service
@Transactional
public class EmpServiceImpl implements EmpService {

	private EmpDao empdao;
	
	public EmpServiceImpl() {
		// TODO Auto-generated constructor stub
	}
	public void setEmpdao(EmpDao empdao) {
		this.empdao = empdao;
	}

	@Override
	@Transactional
	public void addEmployee(Employee employee) {
		empdao.addEmployee(employee);
		
	}

	@Override
	@Transactional
	public void updateEmployee(Employee employee) {
		empdao.updateEmployee(employee);
	}

	@Override
	@Transactional
	public void deleteEmployee(int empid) {
		empdao.deleteEmployee(empid);
	}

	@Override
	public Employee getEmployeeById(int empid) {
		return empdao.getEmployeeById(empid);
	}

	@Override
	public List<Employee> listEmployee() {
		return empdao.listEmployee();
	}

}
