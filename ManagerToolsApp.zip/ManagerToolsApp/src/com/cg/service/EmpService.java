package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;

public interface EmpService {

	public void addEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int empid);
	public Employee getEmployeeById(int empid);
	public List<Employee> listEmployee();
}
