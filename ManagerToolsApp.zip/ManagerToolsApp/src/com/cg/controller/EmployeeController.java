package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.bean.Employee;
import com.cg.service.EmpService;

/*public class EmployeeController {

	@Autowired
	EmpService empservice;
	@RequestMapping("toLogin")
	public String toLogin(Model model) {
		// userName and password will be stored from the login form 
		model.addAttribute("registration", new Employee());
		// "login" will be resolved to login.jsp
		// where login-form is presented to user
		return "login";
}*/
