package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.model.LoginBean;
import com.cg.model.Status;
import com.cg.service.EmpService;


@Controller
public class ManagerEmployeeCntlr {
	@Autowired
	EmpService empservice;
	
	@RequestMapping("toLogin")
	public String toLogin(Model model) {
		// Make sure to add model of UserBean in which login 
		// userName and password will be stored from the login form 
		model.addAttribute("loginBean", new LoginBean());
		// "login" will be resolved to login.jsp
		// where login-form is presented to user
		return "login";
	}	
	
	@RequestMapping("doLogin")
	public ModelAndView doLogin(@ModelAttribute @Valid LoginBean loginBean,BindingResult result,HttpServletRequest request, HttpServletResponse response,HttpSession session) {
		ModelAndView view = new ModelAndView("login");
		// If input bean does not have any validation error then proceed
		if(!result.hasFieldErrors()) {
			// If not a valid user then add error
			// else proceed to user welcome page
			if(!empservice.authenticateUser(loginBean)) {
				result.addError(new ObjectError("err", "Invalid Credentials"));
			} else {
				String name=request.getParameter("role");
				session.setAttribute("user",name); 
				//System.out.println(name);
				if(name.equalsIgnoreCase("manager"))
				{
				view.setViewName("manager");//employee
				}
				else
				{
					view.setViewName("employee");
				}
			}
		}
		return view;
	}
	 @RequestMapping(value="/logout",method = RequestMethod.GET)
     public String logout(HttpServletRequest request){
         HttpSession httpSession = request.getSession();
         httpSession.invalidate();
         return "login";
     }
	    @RequestMapping(value = "/newEmployee", method = RequestMethod.GET)
	    public ModelAndView newContact(ModelAndView model) {
	        LoginBean loginBean = new LoginBean();
	        model.addObject("loginBean", loginBean);
	        model.setViewName("addEmployee");
	        return model;
	    }
	    
	    @RequestMapping(value = "/addstatus", method = RequestMethod.GET)
	    public ModelAndView newStatus(ModelAndView model) {
	        Status status = new Status();
	        model.addObject("status", status);
	        model.setViewName("addStatus");
	        return model;
	    }
	    
	    @RequestMapping(value = "/fillstatus", method = RequestMethod.GET)
	    public ModelAndView newFeedStatus(ModelAndView model, Status status) {
	    	empservice.addStatus(status);
	        model.setViewName("employee");
	        return model;
	    }
	    @RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	    public ModelAndView saveEmployee(@ModelAttribute LoginBean loginBean) {
	        if (loginBean.getEmpid() == 0) { // if employee id is 0 then creating the
	            // employee other updating the employee
	            empservice.addEmployee(loginBean);
	        } else {
	            empservice.updateEmployee(loginBean);
	        }
	        return new ModelAndView("manager");
	    }
	    
	    @RequestMapping(value = "/listdeatils")
	    public ModelAndView listEmployee(ModelAndView model) throws IOException {
	        List<LoginBean> listEmployee = empservice.listEmployee();
	        model.addObject("listEmployee", listEmployee);
	        model.setViewName("listmng");
	        return model;
	    }
	    
	    @RequestMapping(value = "/liststatus")
	    public ModelAndView listStatus(ModelAndView model) throws IOException {
	        List<Status> listStatus = empservice.listStatus();
	        model.addObject("listStatus", listStatus);
	        model.setViewName("liststatus");
	        return model;
	    }
	    
	    @RequestMapping(value="/editemp/{empid}")  
	    public ModelAndView edit(@PathVariable int empid){
	        LoginBean loginBean=empservice.getEmployeeById(empid) ; 
	        return new ModelAndView("edit","command",loginBean);  
	    } 
	    
	    @RequestMapping(value="/editstatus/{statusid}")  
	    public ModelAndView edits(@PathVariable int statusid){
	        Status status=empservice.getStatusById(statusid) ; 
	        return new ModelAndView("edits","command",status);  
	    } 
	    //for employee
	    @RequestMapping(value="/editsave",method = RequestMethod.POST)  
	    public ModelAndView editssave(@ModelAttribute("loginBean") LoginBean loginBean){  
	        empservice.updateEmployee(loginBean); 
	        return new ModelAndView("manager");  
	    } 
	    //forstatus
	    @RequestMapping(value="/editssave",method = RequestMethod.POST)  
	    public ModelAndView editsave(@ModelAttribute("status") Status status){  
	        empservice.updateStatus(status); 
	        return new ModelAndView("manager");  
	    }  
	    
	    @RequestMapping(value="/deleteemp/{empid}",method = RequestMethod.GET)  
	    public ModelAndView delete(@PathVariable int empid){  
	        empservice.deleteEmployee(empid);  
	        return new ModelAndView("manager");  
	    }  
}
