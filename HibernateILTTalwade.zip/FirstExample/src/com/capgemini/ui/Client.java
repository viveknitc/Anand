package com.capgemini.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.capgemini.Employee;
import com.capgemini.utility.HibernateUtil;

public class Client {

	public static void main(String[] args) throws NumberFormatException, IOException {
		
		/*
		Employee employee=new Employee();
		
		employee.setEmpName("Raj");
		employee.setEmpSalary(55000);
		*/
		
		SessionFactory sf=HibernateUtil.getSessionFactory();
		
		Session mySession=sf.openSession();
		
		Transaction txs=mySession.beginTransaction();
		
		//mySession.save(employee);
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Employee id");
		
		int empId=Integer.parseInt(br.readLine());
		
		Employee emp=(Employee)mySession.get(Employee.class,empId);
		if(emp!=null){
			
		
		//emp.setEmpName("xyz");
		//emp.setEmpSalary(90000);
		
		mySession.delete(emp);
		System.out.println("Object is deleted");
		
		
		}
		else{
			
			System.out.println("Sorry employee is not found for"+empId);
		}
		
		
		
		
		
		txs.commit();
		
		
		HibernateUtil.closeSessionFactory();
		
		
		
		
		
		
	}

}
