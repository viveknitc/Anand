package com.capgemini.utility;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	  
	
	   static SessionFactory sf;
	
	
	    public static SessionFactory getSessionFactory(){
		 
	      Configuration configure=new Configuration().configure();
	      sf=configure.buildSessionFactory();
		 
	      return sf;
		 
		 
	 }


	 public static void closeSessionFactory(){
		 
		 sf.close();
		 
		 
	 }
	 


}
