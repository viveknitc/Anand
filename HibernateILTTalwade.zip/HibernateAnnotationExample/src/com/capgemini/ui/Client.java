package com.capgemini.ui;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.capgemini.entity.Address;
import com.capgemini.entity.Student;
import com.capgemini.utility.HibernateUtil;

public class Client {

	public static void main(String[] args) {
		
		  Student student=new Student();
		  
		  student.setStud_name("Ram");
		  
		  Address address=new Address();
		  address.setCity("Pune");
		  address.setCountry("India");
		  address.setState("Maha");
		  address.setStreet("JM Raod");
		  
		  
		  SessionFactory sf=HibernateUtil.getSessionFactory();
		 
		  Session mySession=sf.openSession();
		  
		  
		  
		  Transaction tsx=mySession.beginTransaction();
		
		  student.setAddress(address);
		  address.setStudent(student);
		  
		  mySession.save(student);
		  System.out.println("Object saved");
		  
		      
		   tsx.commit();
	
		   HibernateUtil.closeSessionFactory();
			
	
	
	}

}
