package com.capgemini.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Student {

	 @Id
	 @GeneratedValue(strategy=GenerationType.SEQUENCE)
	 private int stud_rollNumber;
	 private String stud_name;
	 @OneToOne(mappedBy="student",cascade=CascadeType.ALL)
	 private Address address;
	 
	 public Student() {
		// TODO Auto-generated constructor stub
	
	 }

	public int getStud_rollNumber() {
		return stud_rollNumber;
	}

	public void setStud_rollNumber(int stud_rollNumber) {
		this.stud_rollNumber = stud_rollNumber;
	}

	public String getStud_name() {
		return stud_name;
	}

	public void setStud_name(String stud_name) {
		this.stud_name = stud_name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	 
	 




}
