package com.capgemini.ui;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.capgemini.Employee;
import com.capgemini.utility.HibernateUtil;

public class Client {
 
	public static void main(String[] args) {
		
		  
		  SessionFactory sf=HibernateUtil.getSessionFactory();
		 
		  Session mySession=sf.openSession();
		  
		   Transaction tsx=mySession.beginTransaction();
		  
		   /*
		   String selectFieldQuery="select e.empId,e.empSalary from Employee e";
		    
		   String updateQuery="update Employee set empName=:n where empId=:i";
		   
		   
		   String selectQuery="from Employee";
		  
		   Query query=mySession.createQuery(selectFieldQuery);
		  
		   
		    Iterator it= query.iterate();
		   
		    while(it.hasNext()){
		    	
		    	
		    	  Object[] row=(Object[])it.next();
		    	
		    	   System.out.println("id"+row[0]);
		    	   System.out.println("salary"+row[1]);
			    	  
		    	  
		    	  
		    	  
		    	  
		    	
		    }
		      
		    
	           Query queryForUpdate=mySession.createQuery(updateQuery);         
		   
	           queryForUpdate.setParameter("n","xyz");
	         
	           queryForUpdate.setParameter("i",1);
		     
	           int rowCount=queryForUpdate.executeUpdate();
		       System.out.println("number of rows updated are"+rowCount);
		  
		       Query aggrigateQuery=mySession.createQuery("select count(empId) from Employee");
		     
		        List<Integer> aggResult =aggrigateQuery.list();
		       
		        System.out.println("Size is"+aggResult.size());
		       
		        System.out.println("Max salary is"+aggResult.get(0));
		      
		  */
		   
		      Criteria criteria=mySession.createCriteria(Employee.class);
		      criteria.add(Restrictions.le("empSalary",new Float(95000)));
		      
		      List<Float> allEmployee=criteria.list();
		      
		      System.out.println("size is "+allEmployee.size());
		      
		      for(int count=0;count<allEmployee.size();count++)
		      {
		        System.out.println("data is"+allEmployee.get(count));
		      }
		      
		      
		      
		      
		   
		   
		      tsx.commit();
	
		     HibernateUtil.closeSessionFactory();
			
	
	
	}

}
