package com.capgemini.ui;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.cfg.Configuration;

import com.capgemini.entity.Address;
import com.capgemini.entity.Student;

public class Client {

	
	  public static void main(String[] args) {
		
		
		Configuration config=new AnnotationConfiguration().configure();
		System.out.println("fine");
		
		SessionFactory sf=config.buildSessionFactory();
		System.out.println("fine");
		Session mySession=sf.openSession();
		
		Transaction tsx=mySession.beginTransaction();
		
		Address address=new Address();
		
		address.setAddressId(101);
		address.setCity("Pune");
		address.setState("Maharashtra");
		address.setCountry("India");
		address.setStreet("JM Road");
		
		Student student=new Student();
		
		student.setStud_name("Ram");
		
		student.setAddress(address);
	
		
		mySession.save(student);
     
		 address.setStudent(student);
		
		System.out.println("data is saved");
		
		tsx.commit();
		
		
		

	
	
	}

}
