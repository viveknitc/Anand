package com.capgemini.ui;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import oracle.net.aso.q;

import com.capgemini.entity.Employee;

public class Client {

	public static void main(String[] args) {
		
		  Employee employee=new Employee();
		  EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("FirstJPAExample");
		  EntityManager entityManager=entityManagerFactory.createEntityManager();
	      EntityTransaction entityTransaction=entityManager.getTransaction();
		  
	      entityTransaction.begin();
	      
	      employee.setEmpName("Ram");
	      employee.setEmpSalary(50000);
	      
	      //entityManager.persist(employee);
	      
	      //Employee emp=(Employee)entityManager.find(Employee.class,10);
	      
	      
	      
	      //System.out.println(emp);
	      
	      
	       Query query=entityManager.createQuery("select e from Employee e ORDER BY e.empName DESC");
	       
	       Query QueryWithParameter=entityManager.createQuery("select e.empName,e.empSalary from Employee e where e.empId=:myid");
	      
	       QueryWithParameter.setParameter("myid",10);
	       
	       Object row[]=(Object[])QueryWithParameter.getSingleResult();
	       
	       System.out.println(row[0]);
	       
	       
	       //System.out.println(""+row[1]);
	       
	       
	      
	       /*
	       List<Employee> allEmployeeRecord=query.getResultList();
	      
	       System.out.println("size is"+allEmployeeRecord.size());
	       
	       
	       for(Employee e:allEmployeeRecord){
	    	   
	    	   System.out.println(e);
	       }
	       
	       */
	      
	      entityTransaction.commit();
	      
	      
		   //System.out.println("Object is saved in database");
		  
		   entityManagerFactory.close();
	
	
	}

}
