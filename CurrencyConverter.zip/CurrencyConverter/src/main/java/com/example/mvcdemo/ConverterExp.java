package com.example.mvcdemo;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class ConverterExp {
	
	/*public String calculateCurrency(String from, String to,String inp){
		
	   //return (username.equalsIgnoreCase("anil") && password.equalsIgnoreCase("password")) ;
		if(from.equalsIgnoreCase("Dollar") && to.equalsIgnoreCase("INR"))
		{
			double input=Double.parseDouble(inp);
			String result=Double.toString(input*60);
			return result;
		}
		else if(from.equalsIgnoreCase("INR") && to.equalsIgnoreCase("Dollar"))
		{
			double input=Double.parseDouble(inp);
			String result=Double.toString(input/60);
			return result;
		}
		else
			return null;
	
	}*/
	
	public Double getCurrencyMsg(String from,String to,String inp) 
	 {
		RestTemplate restTemplate;
		Double result;
		final String uri = "http://localhost:8080/converse/conversion";
		Currency currency=new Currency();
		currency.setFrom(from);
		currency.setTo(to);
		currency.setInp(inp);
		
		restTemplate = new RestTemplate();
		result =restTemplate.postForObject(uri,currency, Double.class);
		
		return result;
	 }
	
	

}
