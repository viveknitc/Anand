

/**
 * CalculatorImpServiceTest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */
    package com.capgemini;

    /*
     *  CalculatorImpServiceTest Junit test case
    */

    public class CalculatorImpServiceTest extends junit.framework.TestCase{

     
        /**
         * Auto generated test method
         */
        public  void testsum() throws java.lang.Exception{

        com.capgemini.CalculatorImpServiceStub stub =
                    new com.capgemini.CalculatorImpServiceStub();//the default implementation should point to the right endpoint

           com.capgemini.CalculatorImpServiceStub.Sum sum4=
                                                        (com.capgemini.CalculatorImpServiceStub.Sum)getTestObject(com.capgemini.CalculatorImpServiceStub.Sum.class);
                    // TODO : Fill in the sum4 here
                
                        assertNotNull(stub.sum(
                        sum4));
                  



        }
        
         /**
         * Auto generated test method
         */
        public  void testStartsum() throws java.lang.Exception{
            com.capgemini.CalculatorImpServiceStub stub = new com.capgemini.CalculatorImpServiceStub();
             com.capgemini.CalculatorImpServiceStub.Sum sum4=
                                                        (com.capgemini.CalculatorImpServiceStub.Sum)getTestObject(com.capgemini.CalculatorImpServiceStub.Sum.class);
                    // TODO : Fill in the sum4 here
                

                stub.startsum(
                         sum4,
                    new tempCallbackN65548()
                );
              


        }

        private class tempCallbackN65548  extends com.capgemini.CalculatorImpServiceCallbackHandler{
            public tempCallbackN65548(){ super(null);}

            public void receiveResultsum(
                         com.capgemini.CalculatorImpServiceStub.SumResponse result
                            ) {
                
            }

            public void receiveErrorsum(java.lang.Exception e) {
                fail();
            }

        }
      
        //Create an ADBBean and provide it as the test object
        public org.apache.axis2.databinding.ADBBean getTestObject(java.lang.Class type) throws java.lang.Exception{
           return (org.apache.axis2.databinding.ADBBean) type.newInstance();
        }

        
        

    }
    