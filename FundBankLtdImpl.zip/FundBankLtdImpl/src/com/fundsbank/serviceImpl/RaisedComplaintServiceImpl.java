package com.fundsbank.serviceImpl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.mapper.ComplaintRowMapper;
import com.fundsbank.dao.RaisedComplaintDao;
import com.fundsbank.model.ComplaintModel;
import com.fundsbank.service.RaisedComplaintService;

@Service
public class RaisedComplaintServiceImpl implements RaisedComplaintService {
	 @Autowired
	 RaisedComplaintDao raisedComplaintDao;
	 
	@Override
	public int insertComplaint(ComplaintModel complaint) throws SQLException{	

		complaint.setComplaintId(1);	
		if (complaint.getCategory().equals("Internet Banking")) {
			complaint.setPriority("High");
		} else if (complaint.getCategory().equals("General Banking")) {
			complaint.setPriority("Medium");
		}else{
			complaint.setPriority("Low");
		}					
		complaint.setStatus("open");
		
		return raisedComplaintDao.insertComplaint(complaint);
		
	}

	@Override
	public ComplaintModel getComplaint(int complaintId) throws SQLException {
		return raisedComplaintDao.getComplaint(complaintId);
	}

}
