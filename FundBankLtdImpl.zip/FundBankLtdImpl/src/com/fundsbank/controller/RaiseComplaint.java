package com.fundsbank.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fundsbank.model.ComplaintModel;
import com.fundsbank.service.RaisedComplaintService;

@Controller
public class RaiseComplaint {
	@Autowired
	RaisedComplaintService raisedComplaintService;

	static ArrayList<String> catList;
	static {
		catList = new ArrayList<String>();
		catList.add("Internet Banking");
		catList.add("General Banking");
		catList.add("Others");
	}
	//This Controller used for loading home page and adding the category of Complaint
	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String showGreeting(
			@ModelAttribute("rcomp") @Valid ComplaintModel complaintM,
			BindingResult result, Model model) {
			model.addAttribute("cl", catList);
			return "RaiseComplaint";

	}
// This Controller used for validate and process the form of RaiseComplaint and send to model layer
	@RequestMapping(value = "/processComplaint", method = RequestMethod.POST)
	public String processComplaint(
			@ModelAttribute("rcomp") @Valid ComplaintModel complaintM,
			BindingResult result, Model model) throws SQLException{
		//System.out.println(result.getFieldErrorCount());
		if(result.getFieldErrorCount() <= 0)
		{
			int count=0;
			try {
				count = raisedComplaintService.insertComplaint(complaintM);
			} catch (Exception e) {
				e.printStackTrace();
			}
			model.addAttribute("complaintId", count);
			return "success";
		}
		else
		{
			return "RaiseComplaint";
		}

	}
	// This Controller is used to send the control to model after Successful submission
	@RequestMapping(value = "/status", method = RequestMethod.GET)
	public String statusComplaint(
			@ModelAttribute("rstatus") @Valid ComplaintModel statustCom,
			BindingResult result) {
		return "StatusComplaint";
	}
	
	//This Controller used for check the status of given Complaint ID
	@RequestMapping(value = "/datastatus", method = RequestMethod.POST)
	public String statusProcess(
			@ModelAttribute("rstatus") @Valid ComplaintModel statustCom,
			BindingResult result, Model model) throws SQLException {
		ComplaintModel complaintStatus = null;
		try {
			complaintStatus = raisedComplaintService.getComplaint(statustCom.getComplaintId());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(statustCom.getComplaintId());
		if (complaintStatus != null) {
			System.out.println(complaintStatus);
			model.addAttribute("errormsg", "");
			model.addAttribute("complaintId", complaintStatus.getComplaintId());
			model.addAttribute("description", complaintStatus.getDescription());
			model.addAttribute("status", complaintStatus.getStatus());
			return "StatusComplaint";
		}else{
			model.addAttribute("errormsg", "Please Enter correct Complaint Id.");
			return "StatusComplaint";
		}

		
	}
}
