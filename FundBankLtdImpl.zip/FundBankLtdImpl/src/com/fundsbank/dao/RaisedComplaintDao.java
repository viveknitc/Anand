package com.fundsbank.dao;

import java.sql.SQLException;

import com.fundsbank.model.ComplaintModel;

public interface RaisedComplaintDao {
// Given below two  method will implement, one for insert the complaint and  second one for get the status of complaint 
	public int insertComplaint(ComplaintModel complaint) throws SQLException;
	public ComplaintModel getComplaint(int complaintId) throws  SQLException;
}
