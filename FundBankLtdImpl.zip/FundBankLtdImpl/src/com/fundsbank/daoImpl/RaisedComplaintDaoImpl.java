package com.fundsbank.daoImpl;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.capgemini.mapper.ComplaintRowMapper;
import com.fundsbank.dao.RaisedComplaintDao;
import com.fundsbank.model.ComplaintModel;

@Repository
public class RaisedComplaintDaoImpl implements RaisedComplaintDao {
	@Autowired
	JdbcTemplate jt;
	
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	
	@Override
	public int insertComplaint(ComplaintModel complaint) throws SQLException
	{
		System.out.println(complaint);
		//KeyHolder keyHolder = new GeneratedKeyHolder();
		String insertQuery = "insert into complaint values(?, ?, ?, ?, ?, ?, ?, ?)";
		Object[] params = new Object[]{complaint.getComplaintId(), complaint.getAccountId(),complaint.getBranchCode(), complaint.getDescription(), complaint.getCategory(), complaint.getEmailId(), complaint.getPriority(), complaint.getStatus()};
		int count = jt.update(insertQuery, params);
		if(count > 0){
			String lastQuery = "select max(complaintId) from complaint";
			count = jt.queryForInt(lastQuery);
			System.out.println(count);
			
		}
		
		return count;		  

	}

	@Override
	public ComplaintModel getComplaint(int complaintId) throws SQLException {
		ComplaintModel ComplaintModel=null;
		try
		{
		String selectQuery = "select * from complaint where complaintId=?";
		 ComplaintModel = (ComplaintModel) jt.queryForObject(selectQuery, new ComplaintRowMapper(), complaintId);
		System.out.println(ComplaintModel);
		}
		catch(EmptyResultDataAccessException e)
		{
			e.printStackTrace();
		}
		return ComplaintModel;
	
		
	}

}
