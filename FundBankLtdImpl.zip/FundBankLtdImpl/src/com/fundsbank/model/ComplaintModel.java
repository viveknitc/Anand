package com.fundsbank.model;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.stereotype.Component;

@Component
public class ComplaintModel {	

	@NotNull(message="please enter correct Account id in Numeric Format")
	private int accountId;
	@NotNull  	
	private int complaintId;
	@NotEmpty(message="Please enter correct Branch Code")
	private String branchCode;
	
	@NotEmpty(message="Please Enter Email Id")
	@Email
	private String emailId;
	
	@NotEmpty(message="Please Select Category")
	private String category;
	
	@NotEmpty
	@Size(min=10,max=50,message="Please enter Description")
	private String description;
	private String priority;
	private String status;

	public ComplaintModel(){
		
	}
	public ComplaintModel(int complaintId){
		this.complaintId = complaintId;
	}
	
	public ComplaintModel(int complaintId, int accountId, String branchCode,
			String emailId, String category, String description,
			String priority, String status) {
		super();
		this.complaintId = complaintId;
		this.accountId = accountId;
		this.branchCode = branchCode;
		this.emailId = emailId;
		this.category = category;
		this.description = description;
		this.priority = priority;
		this.status = status;
	}	

	public int getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public Integer getAccountId() {
		return accountId;
	}

	public void setAccountId(Integer accountId) {
		this.accountId = accountId;
	}

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ComplaintModel [complaintId=" +complaintId+", accountId="
				+ accountId + ", branchCode=" + branchCode + ", emailId="
				+ emailId + ", category=" + category + ", description="
				+ description + ", priority=" + priority + ", status=" + status
				+ "]";
	}
	
	
	
	
}
