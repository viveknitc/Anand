package com.capgemini.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.capgemini.user.User;
import com.capgemini.user.UserDao;

@Component
public class UserDaoImpl implements UserDao {
	
	@Autowired
	JdbcTemplate jdbctemplate;
	@Override
	public boolean validateUser(User user) {
		boolean userPresent=false;
		String selectQuery="select count(*) from checkUser where username=? and password=?";
		int count=(int)jdbctemplate.queryForInt(selectQuery,user.getUserName(),user.getPassword());
		if(count==1)
		{
			userPresent=true;
		}
		return userPresent;
	}
	
	

}
