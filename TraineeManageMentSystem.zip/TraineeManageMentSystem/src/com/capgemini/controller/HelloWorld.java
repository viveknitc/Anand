package com.capgemini.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.user.User;
import com.capgemini.user.UserDao;

@Controller
public class HelloWorld {
	
	@Autowired
	UserDao userdao;
	@RequestMapping(value="/authentication", method=RequestMethod.GET)
	public String checkUser(Model model,@RequestParam("username") String username,@RequestParam("password") String password)
	{
		User user=new User();
		user.setUserName(username);
		user.setPassword(password);
		boolean flag=userdao.validateUser(user);
		if(flag)
		{
			model.addAttribute("uname", username);
			return "success";
		}
		else
		{
			model.addAttribute("message", "please check username and password");
			return "failure";
		}
		
		
	}
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String takeMeToHomePage()
	{
		return "LoginHome";
	}
}
