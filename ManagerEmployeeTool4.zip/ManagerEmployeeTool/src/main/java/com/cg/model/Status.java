package com.cg.model;

public class Status {
	
	private int statusid;
	private String empuserName;
	private String managerName;
	private String status;
	private String date;
	private String time;
	
	public Status() {
		// TODO Auto-generated constructor stub
	}

	public int getStatusid() {
		return statusid;
	}

	public void setStatusid(int statusid) {
		this.statusid = statusid;
	}

	public String getEmpuserName() {
		return empuserName;
	}

	public void setEmpuserName(String empuserName) {
		this.empuserName = empuserName;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Status [statusid=" + statusid + ", empuserName=" + empuserName
				+ ", managerName=" + managerName + ", status=" + status
				+ ", date=" + date + ", time=" + time + "]";
	}

	

	
	

}
