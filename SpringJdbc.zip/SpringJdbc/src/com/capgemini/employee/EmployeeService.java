package com.capgemini.employee;

public interface EmployeeService  {

	public int addEmployee(Employee employee);
	public Employee getEmployeeById(int eid);
}

