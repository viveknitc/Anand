package com.capgemini.employee.service;

import org.springframework.jdbc.core.JdbcTemplate;

import com.capgemini.employee.Employee;
import com.capgemini.employee.EmployeeRowMapper;
import com.capgemini.employee.EmployeeService;

public class EmployeeServiceImp implements EmployeeService{

	JdbcTemplate jt;
	
	public JdbcTemplate getJt() {
		return jt;
	}

	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}

	@Override
	public int addEmployee(Employee employee) {
		String query="insert into empjdbc values(?,?,?)";
		Object [] params=new Object[]{employee.getId(),employee.getName(),employee.getSal()};
		int count=jt.update(query,params);
		return count;
	}

	@Override
	public Employee getEmployeeById(int eid) {
		
		String selectQuery="select * from employee where eid=?";
		Employee emp=(Employee)jt.queryForObject(selectQuery, new EmployeeRowMapper(),eid);
		return emp;
	}

	
}
