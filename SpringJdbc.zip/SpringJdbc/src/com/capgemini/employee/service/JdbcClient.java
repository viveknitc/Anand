package com.capgemini.employee.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.employee.Employee;

public class JdbcClient {

	public static void main(String[] args) {
		Employee employee=new Employee();
		//EmployeeServiceImp employeeserviceimp=new EmployeeServiceImp();
		employee.setId(121);
		employee.setName("Vivek");
		employee.setSal(123456);
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("ApplicationConfigData.xml");
		EmployeeServiceImp empservice=(EmployeeServiceImp) applicationContext.getBean("empService");
		int rowcount=empservice.addEmployee(employee);
		System.out.println("no of rows Inserted"+rowcount);
	}

}
