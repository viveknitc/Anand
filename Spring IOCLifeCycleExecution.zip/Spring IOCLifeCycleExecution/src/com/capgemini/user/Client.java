package com.capgemini.user;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
	
		ApplicationContext applicationcontext= new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Student student=(Student)applicationcontext.getBean("student");
		System.out.println(student);
	}

}
