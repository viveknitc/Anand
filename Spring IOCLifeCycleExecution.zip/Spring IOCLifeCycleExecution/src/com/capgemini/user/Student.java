package com.capgemini.user;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class Student implements BeanNameAware,BeanFactoryAware,ApplicationContextAware,InitializingBean,DisposableBean {

	private int rollnumber;
	private String name;
	public Student() {
		super();
	}
	public Student(int rollnumber, String name) {
		super();
		this.rollnumber = rollnumber;
		this.name = name;
	}
	public int getRollnumber() {
		return rollnumber;
	}
	public void setRollnumber(int rollnumber) {
		this.rollnumber = rollnumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [rollnumber=" + rollnumber + ", name=" + name + "]";
	}
	@Override
	public void setBeanName(String First) {
		System.out.println("Bean name created : "+First);
		
	}
	@Override
	public void setBeanFactory(BeanFactory Second) throws BeansException {
		System.out.println("Set Bean Factory Called");
		
	}
	@Override
	public void setApplicationContext(ApplicationContext third)
			throws BeansException {
		System.out.println("Set ApplicationContext Called");
		
	}
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("After Properties Set");
		
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("Bean has disposed");
		
	}
	
	
}
