package com.capgemini.user;

public interface UserDao {
	public boolean validateUser(User user);
}
