package com.capgemini.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.sbu.Sbu;

public class Client {

	public static void main(String[] args) {
		ApplicationContext applicationcontext=new ClassPathXmlApplicationContext("ApplicationConfigureData.xml");
		Sbu sbudata=(Sbu)applicationcontext.getBean("sbu");
		System.out.println(sbudata);
	}

}
