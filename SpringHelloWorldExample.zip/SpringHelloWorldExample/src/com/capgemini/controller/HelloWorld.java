package com.capgemini.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloWorld {

	@RequestMapping(value="/greeting", method=RequestMethod.GET)
	public String showGriting(Model model,@RequestParam("message") String  greetingMessage)
	{
		model.addAttribute("gm", greetingMessage);
		return "Welcome";
	}
	
	@RequestMapping(value="/MessageHome", method=RequestMethod.GET)
	public String showGritingMessage(Model model)
	{
		//model.addAttribute("gm", "greetingMessage");
		return "MessageHome";
	}
	
	@RequestMapping(value="/authentication", method=RequestMethod.GET)
	public String checkUser(Model model ,@RequestParam("username") String UserName,@RequestParam("password") String Password)
	{
		if("abc".equals(UserName) && "bbc".equals(Password))
		{
			model.addAttribute("uname",UserName);
			return "success";
		}
		
		else
		{
			model.addAttribute("message","please check username and password");
			return "failure";
		}
	}
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String takeMeToHomePage()
	{
		return "LoginHome";
	}
}
