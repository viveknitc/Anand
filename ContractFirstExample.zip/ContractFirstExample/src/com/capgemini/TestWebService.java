package com.capgemini;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

public class TestWebService {

	public static void main(String[] args) throws RemoteException {
		CalculatorImpServiceStub ciss=new CalculatorImpServiceStub();
		Sum mysum=new Sum();
		mysum.setArg0(20);
		mysum.setArg1(20);
		SumResponse response=ciss.sum(mysum);
		int result=response.get_return();
		System.out.println("Addition is==>"+result);
	}

}
