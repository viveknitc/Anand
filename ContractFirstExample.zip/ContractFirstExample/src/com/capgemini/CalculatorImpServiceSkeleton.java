
/**
 * CalculatorImpServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */
    package com.capgemini;
    /**
     *  CalculatorImpServiceSkeleton java skeleton for the axisService
     */
    public class CalculatorImpServiceSkeleton implements CalculatorImpServiceSkeletonInterface{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param sum0
         */
        
                 public com.capgemini.SumResponse sum
                  (
                  com.capgemini.Sum sum0
                  )
            {
                //TODO : fill this with the necessary business logic
                throw new  java.lang.UnsupportedOperationException("Please implement " + this.getClass().getName() + "#sum");
        }
     
    }
    