
/**
 * CalculatorImpServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.4.1  Built on : Aug 13, 2008 (05:03:35 LKT)
 */
    package com.capgemini;
    /**
     *  CalculatorImpServiceSkeletonInterface java skeleton interface for the axisService
     */
    public interface CalculatorImpServiceSkeletonInterface {
     
         
        /**
         * Auto generated method signature
         * 
                                    * @param sum
         */

        
                public com.capgemini.SumResponse sum
                (
                  com.capgemini.Sum sum
                 )
            ;
        
         }
    