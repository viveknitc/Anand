package com.fundsbank.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fundsbank.model.ComplaintModel;
import com.fundsbank.service.RaisedComplaintService;

@Controller
public class RaiseComplaint {
	@Autowired
	RaisedComplaintService raisedComplaintService;

	static ArrayList<String> catList;
	static {
		catList = new ArrayList<String>();
		catList.add("Internet Banking");
		catList.add("General Banking");
		catList.add("Others");
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String showGreeting(
			@ModelAttribute("rcomp") @Valid ComplaintModel complaintM,
			BindingResult result, Model model) {
		/*
		 * if (result.hasErrors()) { return "home"; } else {
		 */
		model.addAttribute("cl", catList);
		return "RaiseComplaint";
		// }

	}

	@RequestMapping(value = "/processComplaint", method = RequestMethod.POST)
	public String processComplaint(
			@ModelAttribute("rcomp") @Valid ComplaintModel complaintM,
			BindingResult result, Model model) {
		int count = raisedComplaintService.insertComplaint(complaintM);
		model.addAttribute("complaintId", count);
		return "success";

	}

	@RequestMapping(value = "/status", method = RequestMethod.GET)
	public String statusComplaint(
			@ModelAttribute("rstatus") @Valid ComplaintModel statustCom,
			BindingResult result) {
		return "StatusComplaint";
	}

	@RequestMapping(value = "/datastatus", method = RequestMethod.POST)
	public String statusProcess(
			@ModelAttribute("rstatus") @Valid ComplaintModel statustCom,
			BindingResult result, Model model) {
		ComplaintModel complaintStatus = raisedComplaintService
				.getComplaint(statustCom.getComplaintId());
		System.out.println(statustCom.getComplaintId());
		if (complaintStatus != null) {
			System.out.println(complaintStatus);
			model.addAttribute("complaintId", complaintStatus.getComplaintId());
			model.addAttribute("description", complaintStatus.getDescription());
			model.addAttribute("status", complaintStatus.getStatus());
			return "StatusComplaint";
		}

		return "StatusComplaint";
	}
}
