package com.cg.dao;

import java.util.List;
import com.cg.model.LoginBean;
import com.cg.model.Status;

public interface EmpDao {

	public List<LoginBean> listEmployee();
	public List<Status> listStatus();
	public int addEmployee(LoginBean loginBean);
	public void updateEmployee(LoginBean loginBean);
	public void deleteEmployee(int empid);
	public LoginBean getEmployeeById(int empid);
	boolean employeeExists(int empid, String ename);
	public boolean authenticateUser(LoginBean loginBean);
	public void addStatus(Status status);
	//public HashMap<String,String> changePassword(ChangePassword change);
}
