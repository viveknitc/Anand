package com.cg.model;

public class Status {
	
	private String employeeName;
	private String managerName;
	private String status;
	private String date;
	private String time;
	
	public Status() {
		// TODO Auto-generated constructor stub
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getManagerName() {
		return managerName;
	}

	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	@Override
	public String toString() {
		return "Status [employeeName=" + employeeName + ", managerName=" + managerName + ", status=" + status
				+ ", date=" + date + ", time=" + time + "]";
	}
	
	

}
