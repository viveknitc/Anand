package com.cg.service;

import java.util.List;

import com.cg.model.LoginBean;
import com.cg.model.Status;

public interface EmpService {

	public List<LoginBean> listEmployee();
	public int addEmployee(LoginBean loginBean);
	public void updateEmployee(LoginBean loginBean);
	public void deleteEmployee(int empid);
	public LoginBean getEmployeeById(int empid);
	public boolean authenticateUser(LoginBean loginBean);
	public void addStatus(Status status);
}
