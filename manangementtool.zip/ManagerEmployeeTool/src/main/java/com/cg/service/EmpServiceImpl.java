package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.EmpDao;
import com.cg.model.LoginBean;
import com.cg.model.Status;
@Service
public class EmpServiceImpl implements EmpService {
	@Autowired
	public  EmpDao empdao;
	public List<LoginBean> listEmployee() {
		return empdao.listEmployee();
	}

	public int addEmployee(LoginBean loginBean) {

		if(empdao.employeeExists(loginBean.getEmpid(),loginBean.getEname()))
		{
			return 0;
		}
		else
		{
			empdao.addEmployee(loginBean);
			return 1;
		}
	}
	public void updateEmployee(LoginBean loginBean) {
		empdao.updateEmployee(loginBean);
	}

	public void deleteEmployee(int empid) {
		empdao.deleteEmployee(empid);
	}

	public LoginBean getEmployeeById(int empid) {
		return empdao.getEmployeeById(empid);
	}

	public boolean authenticateUser(LoginBean loginBean) {
		return empdao.authenticateUser(loginBean);
	}

	public void addStatus(Status status) {
	 empdao.addStatus(status);
		
	}

}
