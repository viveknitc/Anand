package com.cg.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import com.cg.model.LoginBean;
import com.cg.model.Status;
import com.cg.service.EmpService;


@Controller
public class ManagerEmployeeCntlr {
	@Autowired
	EmpService empservice;
	
	@RequestMapping("toLogin")
	public String toLogin(Model model) {
		// Make sure to add model of UserBean in which login 
		// userName and password will be stored from the login form 
		model.addAttribute("loginBean", new LoginBean());
		// "login" will be resolved to login.jsp
		// where login-form is presented to user
		return "login";
	}	
	
	@RequestMapping("doLogin")
	public ModelAndView doLogin(@ModelAttribute @Valid LoginBean loginBean,BindingResult result) {
		ModelAndView view = new ModelAndView("login");
		// If input bean does not have any validation error then proceed
		if(!result.hasFieldErrors()) {
			// If not a valid user then add error
			// else proceed to user welcome page
			if(!empservice.authenticateUser(loginBean)) {
				result.addError(new ObjectError("err", "Invalid Credentials"));
			} else {
				view.setViewName("addStatus");//manager
			}
		}
		return view;
	}
	 @RequestMapping(value="/logout",method = RequestMethod.GET)
     public String logout(HttpServletRequest request){
         HttpSession httpSession = request.getSession();
         httpSession.invalidate();
         return "login";
     }
	    @RequestMapping(value = "/newEmployee", method = RequestMethod.GET)
	    public ModelAndView newContact(ModelAndView model) {
	        LoginBean loginBean = new LoginBean();
	        model.addObject("loginBean", loginBean);
	        model.setViewName("addEmployee");
	        return model;
	    }
	    
	    @RequestMapping(value = "/addstatus", method = RequestMethod.GET)
	    public ModelAndView newStatus(ModelAndView model) {
	        Status status = new Status();
	        model.addObject("status", status);
	        model.setViewName("addStatus");
	        return model;
	    }
	    @RequestMapping(value = "/saveEmployee", method = RequestMethod.POST)
	    public ModelAndView saveEmployee(@ModelAttribute LoginBean loginBean) {
	        if (loginBean.getEmpid() == 0) { // if employee id is 0 then creating the
	            // employee other updating the employee
	            empservice.addEmployee(loginBean);
	        } else {
	            empservice.updateEmployee(loginBean);
	        }
	        return new ModelAndView("manager");
	    }
	    
	    @RequestMapping(value = "/listdeatils")
	    public ModelAndView listEmployee(ModelAndView model) throws IOException {
	        List<LoginBean> listEmployee = empservice.listEmployee();
	        model.addObject("listEmployee", listEmployee);
	        model.setViewName("listmng");
	        return model;
	    }
	   
	 /*   @RequestMapping(value ="/deleteEmployee/{empid}", method = RequestMethod.GET)
	    public ModelAndView deleteEmployee(HttpServletRequest request) {
	        int employeeId = Integer.parseInt(request.getParameter("empid"));
	        empservice.deleteEmployee(employeeId);
	        return new ModelAndView("manager");
	    }*/
	 
	    /*@RequestMapping(value ="/editEmployee/{empid}", method = RequestMethod.GET)
	    public ModelAndView editContact(HttpServletRequest request) {
	        int employeeId = Integer.parseInt(request.getParameter("empid"));
	        LoginBean loginBean = empservice.getEmployeeById(employeeId);
	        ModelAndView model = new ModelAndView("edit");
	        model.addObject("loginBean", loginBean);
	 
	        return model;
	    }*/
	    
	    @RequestMapping(value="/editEmployee")  
	    public ModelAndView edit(@PathVariable int empid){  
	        LoginBean loginBean=empservice.getEmployeeById(empid);
	        return new ModelAndView("edit","command",loginBean);  
	    }
	    
	    @RequestMapping(value="/deleteEmployee",method = RequestMethod.GET)  
	    public ModelAndView delete(@PathVariable int empid){  
	        empservice.deleteEmployee(empid);  
	        return new ModelAndView("redirect:/listmng");  
	    } 
}
