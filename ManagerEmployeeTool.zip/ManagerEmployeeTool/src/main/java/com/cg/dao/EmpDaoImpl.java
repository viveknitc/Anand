package com.cg.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper; 
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Employee;
@Repository
@Transactional
public class EmpDaoImpl implements EmpDao {
	@Autowired
	public JdbcTemplate jdbcTemplate;

	public void setJdbctemplate(JdbcTemplate jdbctemplate) {
		this.jdbcTemplate = jdbctemplate;
	}

	public List<Employee> listEmployee() {
		String sql="select * from details";
		return jdbcTemplate.query(sql, new RowMapper<Employee>(){

			public Employee mapRow(ResultSet rs, int arg1)
					throws SQLException {
				Employee emp=new Employee();
				emp.setEmpid(rs.getInt(1));
				emp.setEname(rs.getString(2));
				emp.setRole(rs.getString(3));
				emp.setStatus(rs.getString(4));
				emp.setCity(rs.getString(5));
				emp.setMobile(rs.getString(6));
				return emp;
			}
		});
		}
	public int addEmployee(Employee employee) {
		String sql="insert into details(empid,ename,role,status,city,mobile) values("+employee.getEmpid()+",'"+employee.getEname()+"','"+employee.getRole()+"','"+employee.getStatus()+"','"+employee.getCity()+"','"+employee.getMobile()+"')";
		return jdbcTemplate.update(sql);
	}

	public void updateEmployee(Employee employee) {
		
		String sql="update details set Ename='"+employee.getEname()+"',role='"+employee.getRole()+"',status='"+employee.getStatus()+"',city='"+employee.getCity()+"',mobile='"+employee.getMobile()+"'";
		jdbcTemplate.update(sql);
	}

	public void deleteEmployee(int empid) {
		String sql="delete from details where empid="+empid+"";
		jdbcTemplate.update(sql);
	}

	public Employee getEmployeeById(int empid) {
		String sql="select * from details where empid=?";
		return jdbcTemplate.queryForObject(sql,new Object[]{empid},new BeanPropertyRowMapper<Employee>(Employee.class));
	}

	public boolean employeeExists(int empid, String ename) {
		String sql = "SELECT count(*) FROM details WHERE empid = ? and ename=?";
		int count = jdbcTemplate.queryForObject(sql, Integer.class, empid, ename);
		if(count == 0) {
    		        return false;
		} else {
			return true;
		}
	}

}
