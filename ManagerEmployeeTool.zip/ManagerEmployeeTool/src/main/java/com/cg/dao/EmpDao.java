package com.cg.dao;

import java.util.List;

import com.cg.model.Employee;

public interface EmpDao {

	public List<Employee> listEmployee();
	public int addEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int empid);
	public Employee getEmployeeById(int empid);
	boolean employeeExists(int empid, String ename);

	
}
