package com.cg.service;

import java.util.List;

import com.cg.model.Employee;

public interface EmpService {

	public List<Employee> listEmployee();
	public boolean addEmployee(Employee employee);
	public void updateEmployee(Employee employee);
	public void deleteEmployee(int empid);
	public Employee getEmployeeById(int empid);
}
