package com.capgemini;

import javax.jws.WebService;

@WebService(endpointInterface="com.capgemini.Calculator")
public class CalculatorImp implements Calculator {

	@Override
	public int sum(int x, int y) {
		
		return x+y;
	}

}
