package com.capgemini;

import javax.xml.ws.Endpoint;

public class Publisher {

	public static void main(String[] args) {
	
		Endpoint .publish("http://localhost:7070/ws", new CalculatorImp());
		System.out.println("service is published");

	}

}
