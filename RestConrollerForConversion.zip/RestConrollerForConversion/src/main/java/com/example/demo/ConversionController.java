package com.example.demo;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/converse")
public class ConversionController {
@PostMapping(path="/conversion")
public @ResponseBody double welcome(@RequestBody String from,@RequestBody String to,@RequestBody String inp)
{
	double inpvalue;
	inpvalue=Double.parseDouble(inp);
	System.out.println(inpvalue);
	if(inpvalue<0)
	{
		return 0 ; 
	}
	
	
	return 60*inpvalue ;
	
}
}
